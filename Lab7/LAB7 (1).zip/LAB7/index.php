<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>
        function hi(){
            let name = document.getElementById("Score").value;
            let grade;
            if (score >= 91){
                grade = "Excellent";
            } else if (score >= 86) {
                grade = "Great";
            } else if(score >= 81){
                grade = "Good";
            } else if(score >= 75){
                grade = "Nice";
            } else {
                grade = "Failed!"
            }
            document.getElementById("content").innerHTML = "<p>" + grade + "</p>";
            let totalScore = document.getElementById("TotalScore").value;
            let percentage = (score / totalScore) * 100;
            document.getElementById("Grade").innerHTML = percentage.toFixed(2) + "%";
        }
    </script>

    <p id = "content"></p>
    <input type="text" id = "Score" placeholder="Enter your score">
    <input type="text" id = "total Score" placeholder="Total Score">
    <select id="mode">
        <option value="hi">Pass/Fail</option>
        <option value="hi">Percentage</option>
    </select>
    <button onclick="percentage()">Calculate Grade</button>
    <button onclick="grade()">Calculate Grade</button>
    Percentage: <span id="percentage"></span>
</body>
<img src="on.png" alt="on">
<img src="off.png" alt="on">

</html>
